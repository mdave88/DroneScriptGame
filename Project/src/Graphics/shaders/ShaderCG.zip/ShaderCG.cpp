/*
 * ShaderCG.cpp
 *
 *  Created on: 2010.03.30.
 *      Author: dave
 */

#include "ShaderCG.h"

ShaderCG::ShaderCG() {

}

ShaderCG::ShaderCG(char* filename) {
	load(filename);
}

void ShaderCG::load(char* filename) {
	cout << "loading shader " << filename << endl;
	shaderContext = cgCreateContext();

	string ShaderNameS(filename);

	VP = cgGLGetLatestProfile(CG_GL_VERTEX);
	cgGLEnableProfile(VP);
	vertexProg = cgCreateProgramFromFile(shaderContext, CG_SOURCE, (char*) (ShaderNameS + ".vp").c_str(), VP, NULL, NULL);

	cout << "\t" << "vertex shader: " << cgGetErrorString(cgGetError()) << endl;

	cgGLLoadProgram(vertexProg);
	cgGLBindProgram(vertexProg);


	PP = cgGLGetLatestProfile(CG_GL_FRAGMENT);
	cgGLEnableProfile(PP);
	pixelProg = cgCreateProgramFromFile(shaderContext, CG_SOURCE, (char*) (ShaderNameS + ".fp").c_str(), PP, NULL, NULL);
	cgGLLoadProgram(pixelProg);
	cgGLBindProgram(pixelProg);

	cout << "\t" << "fragment shader: " << cgGetErrorString(cgGetError()) << endl;

	//MVPT = cgGetNamedParameter(vertexProg, "modelViewProj");
	elapsedTime = cgGetNamedParameter(pixelProg, "time");

	cout << endl;
}

void ShaderCG::bind() {
	cgGLBindProgram(vertexProg);
	cgGLBindProgram(pixelProg);
}

void ShaderCG::enable() {
	cgGLEnableProfile(VP);
	cgGLEnableProfile(PP);
}

void ShaderCG::disable() {
	cgGLDisableProfile(VP);
	cgGLDisableProfile(PP);
}

void ShaderCG::setUniform1i(char* uniformName, GLuint value) {
	cgGLSetTextureParameter(cgGetNamedParameter(pixelProg, uniformName), value);
}

void ShaderCG::setUniform1f(char* uniformName, GLfloat value) {
	cgGLSetParameter1f(cgGetNamedParameter(pixelProg, uniformName), value);
}

void ShaderCG::setUniform3f(char* uniformName, vec3 values) {
	cgGLSetParameter3f(cgGetNamedParameter(pixelProg, uniformName), values.x, values.y, values.z);
}
