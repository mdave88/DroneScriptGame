/*
 * ShaderCG.h
 *
 *  Created on: 2010.03.30.
 *      Author: dave
 */

#ifndef SHADERCG_H
#define SHADERCG_H

#include "../includes.h"

class ShaderCG {
	CGprofile VP;
	CGprofile PP;

public:
	CGcontext shaderContext;
	CGprogram vertexProg, pixelProg;

	CGparameter MVPT, elapsedTime;

public:
	ShaderCG();
	ShaderCG(char* filename);

	void load(char* filename);

	void bind();
	void enable();
	void disable();

	void setUniform1i(char* uniformName, GLuint value);
	void setUniform1f(char* uniformName, GLfloat value);
	void setUniform3f(char* uniformName, vec3 values);
};

#endif
